
<?php $__env->startSection('content'); ?>

<style>
    .content ul{
        list-style: none !important;
    }
    .content ul li{
        margin-left: 18px;
        margin-right: 0px;
        margin-bottom: 40px;
        display: inline-block;
        padding: 4px;
        border-radius: 4px;
        box-shadow:0 1px 3px 0px rgb(0 0 0 / 20%), 0 2px 1px -1px rgb(0 0 0 / 12%), 0 1px 1px 0 rgb(0 0 0 / 14%);
        }
    .content ul li:hover{
        box-shadow: 1px 2px 10px 0px rgba(0,0,0,0.5);
        }</style>
    <ul style="text-align: center;"><!--بعيدا عن انه الكود هون غبي بس حاول تخليه زي ما هو عشان الخصم والسعر الجديد الخ-->
      <?php if(session('success')): ?>
      <div class="alert alert-success">
          <?php echo e(session('success')); ?>

      </div>
  <?php endif; ?>
   
      <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
      <li>
        <div class="product">
         <div id="pro_img">
          <a ><img src="<?php echo e(asset('storage/'. $item['image'])); ?>" width="168px" height="168px"></a>  
         <div id="pro_title">
           <a ><?php echo e($item['name']); ?></a> 
         </div>
         <br>
         <br>
       
        <div id="pro_price">
        <a href="#"><?php echo $item['price']*((100-$item['discount'])/100) ;?></a>
        </div>
        <div id="pro_per">
          <?php if($item['discount'] !=null): ?> 
        <a href="#"><?php echo e($item['discount']); ?>%-</a>
        <?php endif; ?>
        </div>
        <br>
        
        <div id="pro_pricel">
        <h6 id="pro_t">شامل الضريبة</h6>
        <?php if($item['discount'] !=null): ?> 
        <a href="#"><?php echo e($item['price']); ?> د.أ</a>
        <?php endif; ?>
        </div>
        <?php if($item['discount'] !=null): ?> 
        <div id="pro_save">
        <a href="#"><i class="fa-solid fa-tag"></i> وفّر: <?php echo e($item['price']*$item['discount']/100); ?> د.أ</a>
        </div>
        <?php endif; ?>
        <div id="buyl">
        <div id="buyr">
        <div id="pro_buy">
        
             <a href="#">
               <i class="fa-regular fa-cart-circle-plus" style="color: #1e3250;"></i></a>
         </div><div id="pro_buy">
          <form action="<?php echo e(route('remove.from.wish', ['id' => $item->id])); ?>" id="ajax-form" method="post">
            <?php echo csrf_field(); ?>
            <a href="#" >                
              <div id="hid">
              <button type="submit" name="favb">
              <i class="fa-solid fa-heart-circle-plus"></i>
                </button>
               </a>
        </form>
             
              
         </div></div></div></div>
        </div>
            </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <script>
      jQuery.noConflict();
    
    // Now you can use "jQuery" instead of "$" in your code
    jQuery(document).ready(function($) {
      // Your jQuery code here
    
      $('#ajax-form').submit(function(e) {
            e.preventDefault();
           
            var url = $(this).attr("action");
            let formData = new FormData(this);
      
            $.ajax({
                    type:'POST',
                    url: url,
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: (response) => {
                        alert(response.success);
                        location.reload();
                    },
                    error: function(response){
                        $('#ajax-form').find(".print-error-msg").find("ul").html('');
                        $('#ajax-form').find(".print-error-msg").css('display','block');
                        $.each( response.responseJSON.errors, function( key, value ) {
                            $('#ajax-form').find(".print-error-msg").find("ul").append('<li>'+value+'</li>');
                        });
                    }
               });
              });
          
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('public._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cards-store\resources\views/public/fav.blade.php ENDPATH**/ ?>