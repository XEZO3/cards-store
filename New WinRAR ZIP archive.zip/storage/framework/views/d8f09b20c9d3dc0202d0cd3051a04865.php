<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['item']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['item']); ?>
<?php foreach (array_filter((['item']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
    
    <li>
        <div class="product">
         <div id="pro_img">
          <a ><img src="<?php echo e(URL::asset('images/product/playcard.png')); ?>" width="168px" height="168px"></a>  
         <div id="pro_title">
           <a ><?php echo e($item['name']); ?></a> 
         </div>
         <br>
         <br>
       
        <div id="pro_price">
        <a href="#"><?php echo $item['price']*((100-$item['discount'])/100) ;?></a>
        </div>
        <div id="pro_per">
          <?php if($item['discount'] !=null): ?> 
        <a href="#"><?php echo e($item['discount']); ?>%-</a>
        <?php endif; ?>
        </div>
        <br>
        
        <div id="pro_pricel">
        <h6 id="pro_t">شامل الضريبة</h6>
        <?php if($item['discount'] !=null): ?> 
        <a href="#"><?php echo e($item['price']); ?> د.أ</a>
        <?php endif; ?>
        </div>
        <?php if($item['discount'] !=null): ?> 
        <div id="pro_save">
        <a href="#"><i class="fa-solid fa-tag"></i> وفّر: <?php echo e($item['price']*$item['discount']/100); ?> د.أ</a>
        </div>
        <?php endif; ?>
        <div id="buyl">
        <div id="buyr">
        <div id="pro_buy">
        <form action="<?php echo e(route('add.to.cart', ['id' => $item->id])); ?>" method="post">
          <?php echo csrf_field(); ?>

             <a href="#">
              <button type="submit" name="favb">
               <i class="fa-regular fa-cart-circle-plus" style="color: #1e3250;"></i>
              </button>

              </a>
            </form>

         </div>
         <div id="pro_buy">
          
            <a href="#"  wire:click="addToWish(1)">                
              <div id="hid">
              <button  name="favb">
              <i class="fa-solid fa-heart-circle-plus"></i>
                </button>
               </a>
        
             
              
         </div></div></div></div>
        </div>
            </li>




<?php /**PATH C:\xampp\htdocs\cards-store\resources\views/livewire/card.blade.php ENDPATH**/ ?>