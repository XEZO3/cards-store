
<?php $__env->startSection('content'); ?>
<div class="container border rounded ">

    <div class="adminbody">
        <form action="/admin/register" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <label>إسم المستخدم</label>
            <input type="text" name="name" style="padding: 10px;width: 80%;border: 1px solid #eee;font-family: tahoma;font-size: 12px;color: #000;">
            <br>
            <?php $__errorArgs = ['ىشةث'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>
            <label>البريد الالكتروني</label>
            <input type="email" name="email" style="padding: 10px;width: 80%;border: 1px solid #eee;font-family: tahoma;font-size: 12px;color: #000;">
            <br>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>
            <label>كلمة السر</label>
            <input type="password" name="password" style="padding: 10px;width: 80%;border: 1px solid #eee;font-family: tahoma;font-size: 12px;color: #000;">
            <br>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>
            <label> اعد كلمة السر</label>
            <input type="password" name="password_confirmation" style="padding: 10px;width: 80%;border: 1px solid #eee;font-family: tahoma;font-size: 12px;color: #000;">
            <br>
            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>       
            <input type="submit" value="إضافة مسؤول">
            </form>
        </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cards-store\resources\views/admin/register.blade.php ENDPATH**/ ?>