
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        </div>
    </div>
  
    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">الاسم</th>
            <th scope="col">الهاتف</th>
            <th scope="col">الفئة</th>
            <th scope="col">المنطقة</th>
            <th scope="col">####</th>

          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
           
          <tr>
            <th scope="row"><?php echo e($index+1); ?></th>
            <td ><?php echo e($item['name']); ?></td>
            <td><?php echo e($item['phone_number']); ?></td>
            <td><?php echo e($item['type']); ?></td>
            <td><?php echo e($item['country']); ?></td>
            <td>
                <div class="d-flex flex-row ">
                    <div ><a href="/admin/agents/edit/<?php echo e($item['id']); ?>"  class="btn btn-primary">
                      <i style="color: white" class="material-icons ">تعديل</i>
                    </a></div>
                    <div ><a href="/admin/agents/delete/<?php echo e($item['id']); ?>" class="btn btn-danger mr-1">
                      <i class="material-icons" style="color: white">حذف</i>
                    </a></div>
                  </div>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <a href="/admin/agents/add" class="btn btn-primary" style="color: white"> اضافة المزيد</a>
</div>


  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cards-store\resources\views/admin/agents/show.blade.php ENDPATH**/ ?>