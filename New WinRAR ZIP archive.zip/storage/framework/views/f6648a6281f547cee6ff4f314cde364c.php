



<?php $__env->startSection('content'); ?>


<style>body{background-color: #e0e0e0}</style>
<table class="agent">
<tr>
    <td class="namea">الإسم</td>
    <td class="phonea">جوال</td>
    <td class="cata">الفئة</td>
    <td class="regiona">المنطقة</td>
    </tr>
    <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><td><br></td></tr>

    <tr style="background: #fff;
    border-radius: calc(0.25rem - 1px) calc(0.25rem - 1px) 0 0;
    box-shadow: 0 1px 3px 0px #0000000f;
    width: 100% !important;
    height: 70px;">
    <td class="allb"><?php echo e($item['name']); ?></td>
    <td class="allb"><a href="https://wa.me/<?php echo e($item['phone_number']); ?>"><i class="fa-brands fa-whatsapp fa-2xl" style="color: #34dd31;"></i></a></td><!---->
    <td class="allb"><?php echo e($item['type']); ?></td>
    <td class="allb"><?php echo e($item['country']); ?></td>
        </tr>
    <tr><td><br></td></tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('public._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cards-store\resources\views/public/agents.blade.php ENDPATH**/ ?>