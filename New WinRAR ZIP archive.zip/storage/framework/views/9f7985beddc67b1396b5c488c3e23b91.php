
<?php $__env->startSection('content'); ?>


<style>.headertop{visibility: hidden;overflow: hidden}</style> 
<script src="https://getbootstrap.com/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
<style>
    .headertop{
        visibility: hidden;
    }
    html,
body {
  height: 100%;
    direction: rtl !important;
}

.form-signin {
  max-width: 330px;
  padding: 1rem;
}

.form-signin .form-floating:focus-within {
  z-index: 2;
}

.form-signin input[type="email"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}

.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
</style>
   

<main class="form-signin w-100 m-auto">
  <form method="post" action="/user/login">
    <?php echo csrf_field(); ?>
      <a href="/">
    <img class="mb-4" src="<?php echo e(URL::asset('images/logo.png')); ?>"  alt="logo" width="72" height="57" style="display: block;">
  </a><!--this is logo so modify it-->
    <h1 class="h3 mb-3 fw-normal" style="text-align:right">تسجيل الدخول</h1>

    <div class="form-floating">
      <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@example.com" aria-describedby="emailHelp">
      <label for="floatingInput">البريد الالكتروني</label>
      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <small class="text-danger"><?php echo e($message); ?></small>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-floating">
      <input type="password" name="password" class="form-control" id="floatingPassword" id="exampleInputPassword1">
      <label for="floatingPassword">كلمة السر</label>
    </div>

    
   
    <button class="btn btn-primary w-100 py-2" type="submit">Sign in</button>
    <p>ليس لديك حساب؟ <a href="/user/register" style="text-decoration:none;cursor:poiner;">سجل الآن</a></p>
  </form>
</main>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('public._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cards-store\resources\views/public/login.blade.php ENDPATH**/ ?>