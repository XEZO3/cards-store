
<?php $__env->startSection('content'); ?>

<div class="container ">
    <div class="row justify-content-center" onload="dis()">  
    <div class="col-7">
    <form action="/admin/info/update/<?php echo e($siteInfo['id']); ?>"  method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label>إسم الموقع </label>
        <input type="text" name="name" class="form-control" value="<?php echo e($siteInfo['name']); ?>">
        <br>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <label>رقم التواصل</label>
        <input type="text" name="phone_number" class="form-control mos" value="<?php echo e($siteInfo['phone_number']); ?>">
        <br>
        <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <label>البريد الالكتروني</label>
        <input type="text" name="email"  class="form-control tes" value="<?php echo e($siteInfo['email']); ?>">
        <br>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <label>شعار الموقع</label>
        <img style="width: 80px;height:80px"  src="<?php echo e(asset('storage/'. $siteInfo['logo'])); ?>"/>
        <input type="file" class="form-control tes" name="image">
        <br>
        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <button type="submit" id="hide" class="btn btn-primary">حفظ التعديلات</button>
        </form><br>
        <button class="btn btn-primary" id="edit" onclick="appere()">تعديل</button>
        <button class="btn btn-danger" id="cancel" onclick="disappere()">الغاء</button>
        <br>
    </div>
</div>
</div>
<script>
    var elements = document.getElementsByClassName("form-control");
        for (var i = 0; i < elements.length; i++) {
            elements[i].disabled = true;
        }
        document.getElementById("hide").style.visibility = "hidden"
        document.getElementById("cancel").style.visibility = "hidden"

        function appere(){
            var elements = document.getElementsByClassName("form-control");
        for (var i = 0; i < elements.length; i++) {
            elements[i].disabled = false;
        }
        document.getElementById("hide").style.visibility = "visible"
        document.getElementById("edit").style.visibility = "hidden"
        document.getElementById("cancel").style.visibility = "visible"

        }
        function disappere(){
            var elements = document.getElementsByClassName("form-control");
        for (var i = 0; i < elements.length; i++) {
            elements[i].disabled = true;
        }
        document.getElementById("hide").style.visibility = "hidden"
        document.getElementById("edit").style.visibility = "visible"
        document.getElementById("cancel").style.visibility = "hidden"

        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cards-store\resources\views/admin/home/siteInfo.blade.php ENDPATH**/ ?>