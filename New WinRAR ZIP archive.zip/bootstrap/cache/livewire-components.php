<?php return array (
  'card' => 'App\\Http\\Livewire\\Card',
);